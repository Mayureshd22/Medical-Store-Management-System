    /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Kunal
 */
import java.sql.*;
import javax.swing.JOptionPane;

public class db {
Connection conn;

public static Connection ConnectDb(){
    try{
        Class.forName("org.sqlite.JDBC");
        Connection conn=DriverManager.getConnection("jdbc:sqlite:C:\\Users\\User\\Desktop\\omkarupdate\\MMS 2.0 (Omkar)\\db.db");
       return conn;
    }catch (Exception e){
        JOptionPane.showMessageDialog(null, e);
        return null;
    }
}
}
